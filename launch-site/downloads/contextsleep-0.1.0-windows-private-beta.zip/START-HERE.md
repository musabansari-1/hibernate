# ContextSleep 0.1.0 — private beta

Run **ContextSleep.exe** on Windows 10/11 with WebView2 and Windows Terminal installed. Keep hibernate-host.exe beside it. This folder does not need Node, Rust or this source checkout to run.

ContextSleep is a local-first private beta for putting away supported development-workspace context and reconstructing it with verification. The packaged VS Code + Chrome + approved-service lifecycle has passed end to end. This build is unsigned; Explorer and arbitrary terminal windows are Context Restore only, ambiguous close targets stay open, and actual Windows reboot recovery is not yet validated. No adapter claims arbitrary app state or full process hibernation. Review SAFETY.md. Closing the dashboard hides it to the tray; use the tray's Quit action to exit.

## Fast app setup

The easiest path is inside ContextSleep: choose **Connect apps -> Set up apps automatically**. ContextSleep installs the packaged VS Code extension, prepares the stable local bridge, pre-registers Chrome for the bundled stable extension ID, opens chrome://extensions, and opens the exact extension folder.

Chrome still requires one browser-security confirmation: enable Developer mode, click **Load unpacked**, and select the folder ContextSleep opened. No extension-ID copy/paste and no manual Connect/refresh step are required; the extension reconnects automatically after Chrome loads it.

SETUP.ps1 remains an optional command-line fallback. It uses the same stable Chrome extension ID automatically:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SETUP.ps1 -InstallVSCode -RegisterChrome -Launch
```

Run SETUP.ps1 without switches to see the available fallback actions.

## Chrome integration

1. Prefer **Connect apps -> Set up apps automatically** in ContextSleep.
2. When Chrome opens chrome://extensions, enable Developer mode and click **Load unpacked**.
3. Select the chrome-extension folder ContextSleep opened. The local bridge is already registered for the bundled stable ID and the extension connects automatically.

Advanced/manual fallback only:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\register-native-host.ps1 -ExtensionId lilgdmjjanejoihlpegfklkfaofebfhn -HostPath .\hibernate-host.exe
```

The script registers only this host and extension for your account. It refuses to replace another application's registration. Existing snapshots remain in your local application data.

## VS Code integration

Open ContextSleep and use **Connect apps → Install VS Code integration**. ContextSleep installs contextsleep-0.1.0.vsix and prepares a stable local bridge under your Windows profile. Open or reload a trusted local repository and the extension auto-connects. Advanced users can still set hibernate.nativeHostPath manually to override the bridge path.

ContextSleep: Open Instrumented Project Terminal creates a no-profile PowerShell shell that reports its working directory. Existing arbitrary terminal commands are never replayed. Reviewed clean VS Code close can be verified when its workbench window is unambiguous and its GUI process exits. Multiple workbench windows sharing a process block reviewed closure.

## First project

Create a workspace, choose its folder, assign its app windows, then **Capture workspace context**. Choose **Review and sleep**, inspect the saved state, select supported windows/services and confirm saved work. All selected parts are checked before the first close and rechecked before each close. A failed or unverified close stops later work. Unsupported contexts remain visible and may continue using resources. Before relying on cold restore for Chrome, open **Chrome profile binding** once and save that enrolled profile's directory (for example `Default`). With the VS Code extension installed and its native-host path configured, checkpoint restore can reopen the saved local workspace and wait for the same integration identity to reconnect. Restarting saved development services requires selecting the checkpoint service part and explicitly approving its saved direct Node/Python command.

Upgrade the desktop, native host and integrations together. This build upgrades the database to schema 5 for durable native close observation. Older builds cannot open the upgraded database. Interrupted project operations are never replayed automatically; queued project closes are canceled at startup.

Data is stored in %LOCALAPPDATA%\ProjectHibernate. Semantic payloads and .hibernate backups use current-account DPAPI. IDs and resource metrics are not encrypted; this does not protect against programs running as your account. Keep the original account and integration identities when relying on saved contexts.

## Distribution integrity

SHA256SUMS.json records packaged file hashes. Hashes detect accidental changes; they do not replace publisher signing. This build has no installer or automatic updates.
