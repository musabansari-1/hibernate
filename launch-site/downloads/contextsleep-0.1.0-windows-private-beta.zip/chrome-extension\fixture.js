// extensions/chrome/src/fixture.ts
var index = new URL(location.href).searchParams.get("tab") ?? "1";
document.title = `Validation ${index} \xB7 Hibernate`;
document.querySelector("#title").textContent = `Workspace validation page ${index}`;
var buffer = new Uint8Array(8 * 1024 * 1024);
buffer.fill(37);
globalThis.hibernateFixture = buffer;
document.querySelector("#status").textContent = "8 MiB test buffer allocated. Safe to close.";
